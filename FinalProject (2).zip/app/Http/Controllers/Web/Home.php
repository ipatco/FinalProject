<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Course;
use App\Models\Transaction;
use App\View\Components\CategoryMenu;
use Illuminate\Http\Request;
use Razorpay\Api\Api;
use Session;
use Exception;
use Illuminate\Support\Facades\Auth;

class Home extends Controller
{
    public function index()
    {
        $categories = Category::limit(8)->get();
        $courses = Course::orderByDesc('id')->get();
        // dd($courses);
        return view('web.home', compact('courses', 'categories'));
    }

    public function category()
    {
        return view('web.category');
    }

    public function courseDetail($slug)
    {
        $course = (new Course())->with('courseEligibility', 'courseModule', 'courseBenifits', 'courseFeature', 'courseFee', 'courseLearn', 'courseSkill', 'courseTool', 'careerService', 'faq')->where('slug', $slug)->get()->first();
        // dd($course);
        return view('web.detail', compact('course'));
    }

    public function exploreCourse()
    {
        $courses = (new Course())->paginate(10);
        // dd($courses);
        return view('web.explore', compact('courses'));
    }

    public function corporateTraining()
    {
        return view('web.corporate-training');
    }

    public function contact()
    {
        return view('web.contact');
    }

    public function coursePurchase($slug)
    {
        $course = (new Course())->where('slug', $slug)->get()->first();
        return view('web.purchase', compact('course'));
    }

    public function coursePurchased(Request $request)
    {
        $input = $request->all();
        $api = new Api(env('RAZORPAY_KEY'), env('RAZORPAY_SECRET'));
        $payment = $api->payment->fetch($input['razorpay_payment_id']);
        if (count($input)  && !empty($input['razorpay_payment_id'])) {
            try {
                $response = $api->payment->fetch($input['razorpay_payment_id'])->capture(array('amount' => $payment['amount']));
                // dd($response->id);
                $transaction = new Transaction();
                $transaction->amount = $response->currency . ' ' . ($response->amount / 100);
                $transaction->order_id = $response->created_at;
                $transaction->payment_id = $response->id;
                $transaction->signature = md5(uniqid(rand(), true));
                $transaction->verified = ($response->status == 'captured' ? 'verified' : '');
                $transaction->method = 'Razorpay: ' . $response->method;
                $transaction->course_id = $request->input('course_id');
                $transaction->user_id = Auth::user()->id;
                $transaction->save();
            } catch (Exception $e) {
                Session::put('error', $e->getMessage());
                return redirect()->back();
            }
        }
        Session::put('success', 'Payment successful');
        return redirect()->route('user.account.course');
    }

    public function redirectAuth()
    {
        $role = Auth::user()->role;
        if ($role == 'user') {
            return redirect()->route('user.account');
        } elseif ($role == 'admin') {
            return redirect()->route('admin.dashboard');
        }
        return redirect()->route('web.home');
    }
}
